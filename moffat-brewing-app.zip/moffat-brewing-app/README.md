# Moffat Beach Brewing Co. — App MVP

A mobile-first, static HTML/CSS/JavaScript prototype inspired by the selected landing-page mockup. No dependencies or build step required.

## Preview
Open `index.html` in a browser. For GitHub Pages, push the contents of this folder to the repository root, then enable **Settings → Pages → Deploy from a branch → main / root**.

## Included
- Responsive branded home page using the supplied logo
- Seven interactive navigation tiles
- Working placeholder pages for each section
- iPhone safe-area support and basic accessibility

## Future development
- Replace placeholder screens with real beer, venue, menu, tour, membership, rewards and loyalty data.
- Add a secure backend and authentication before introducing accounts, payment, or loyalty balances.
- If targeting the iOS App Store, plan a native SwiftUI shell or an appropriate mobile app wrapper with genuinely app-like functionality; GitHub Pages by itself hosts a website, not an App Store app.

This is a functional **web MVP**, not a finished native iOS app. The artwork in the generated mockup is a visual reference; this version uses CSS treatments and the supplied logo rather than extracting images from the mockup.
